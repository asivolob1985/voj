<?php

namespace App;

class HowWork extends BaseModel
{
    
}
