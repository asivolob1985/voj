<?php

namespace App;

class Tech extends BaseModel {

}
