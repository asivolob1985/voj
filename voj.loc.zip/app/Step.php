<?php

namespace App;

class Step extends BaseModel {

}
