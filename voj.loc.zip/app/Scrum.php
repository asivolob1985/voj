<?php

namespace App;

class Scrum extends BaseModel
{
    
}
