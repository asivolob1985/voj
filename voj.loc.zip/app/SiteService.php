<?php

namespace App;

class SiteService extends BaseModel
{
    
}
