<?php

namespace App;


class Banner extends BaseModel {
    
}
