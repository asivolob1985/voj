<?php

namespace App\Http\Controllers;

use GuzzleHttp;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Str;

class TestController extends SiteController {

	public function __invoke($action){

		return $this->$action();
	}

	public function test(){
		return view('test');
	}

	public function sendform(){
	    $name = 'andrey';
	    $tel = '89652707522';
	    $data = compact('name', 'tel');
        $request = Request::create(route('form.order'), 'POST', $data);
        $orc = new FormController();
        $data = $orc->order($request);


        dd($data);

    }
}