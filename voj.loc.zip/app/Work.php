<?php

namespace App;

class Work extends BaseModel {

}
