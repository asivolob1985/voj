<?php

namespace App;

class ServiceSupport extends BaseModel
{
    
}
