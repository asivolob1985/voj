<?php

namespace App;


class Service extends BaseModel
{
    
}
