<?php
 dump($all_projects);
 
