<p>Имя - {{ $order->name }}</p>
<p>Фамилия - {{ $order->last_name }}</p>
<p>Отчество - {{ $order->middle_name }}</p>
<p>Телефон - {{ $order->tel }}</p>
<p>Почта - {{ $order->email }}</p>
<p>Место работы/учебы - {{ $order->working_place }}</p>
<p>Класс обучения - {{ $order->learning_class_course }}</p>
<p>Как узнали - {{ $order->known }}</p>
<p>Текст - {{ $order->text }}</p>