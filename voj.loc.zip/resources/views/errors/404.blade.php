@section('title', __('elements.404_name'))
@include('layouts.header')
<!-- 404 контент -->
404
<!-- конец 404 контент -->
@include('layouts.footer')
