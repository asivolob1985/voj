<p>ADVANTAGES</p>
<? dump($advantages) ?>
<? dump($config) ?>
<? dump($data) ?>