<?php

return [
	'form_name_main' => 'Отправить заявку? Легко!',
	'form_button_name' => 'Начать  проект',
	// общие вопросы и данные
	//вопросы
	'form_question_name' => 'Имя',
	'form_question_tel' => 'Телефон',
	'form_question_known' => 'Как вы узнали о нас?',
	'form_question_service' => 'Услуга',
	'form_question_budget' => 'Бюджет в рублях',
	//
	'success_thank' => "Заявка успешно отправлена!",
	'success_desc' => "Наш менеджер перезвонит Вам в ближайшее время!",
	'success_button' => "ОК",
	'success_fail_name' => "Ошибка отправки заявки",
];
