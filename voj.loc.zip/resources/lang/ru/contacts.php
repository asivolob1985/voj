<?php

return [
	'name' => 'Контакты',
];
